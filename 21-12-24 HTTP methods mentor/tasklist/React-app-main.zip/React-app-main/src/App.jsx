/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */

import "./App.css";

import TaskApp from "./site/Tasks/TaskApp";

function App() {
  return (
    <div id="app">
      <TaskApp />
    </div>
  );
}
export default App;
